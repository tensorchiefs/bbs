library(compositions)
library(partitions)
library(compositions)
library(rgl)
library(mvtnorm)

# what does this stuff look like? (slide 5)

dummycomp <- t(compositions(n=30, m=3))
dummycomp <- dummycomp[apply(dummycomp, 1, function(z) all(z>0)),]
dummycomp <- dummycomp / 30

# bounded set within a subspace

plot3d(dummycomp)

# ternary plot using "compositions package"
# acomp objects are the main compositional data type (closed)

plot(acomp(dummycomp), pch = 20)


# subcompositions and closing (slide 7)

load("compo.RData")

head(compo)
rowSums(compo)



compoAlSiCaNa <- compo[,1:4]
rowSums(compoAlSiCaNa)

compoAlSiCaNa <- clo(compoAlSiCaNa)
rowSums(compoAlSiCaNa)

# convert to acomp object
compoAlSiCaNa <- acomp(compoAlSiCaNa)
plot(compoAlSiCaNa) # standard mariginalization uses geom. mean
plot(compoAlSiCaNa, margin = "rcomp") # add others (amalgamation)

# change of units
# we use nutrition data set downloadable from 
# http://www.stat.boogaart.de/compositionsRBook/
#
# measurements are mass proportions (in g, except for sodium which is in mg)

nutrition <- read.table("SimpleData.txt", sep="")
nutrition <- acomp(nutrition[,c("Fat" ,"Protein", "Carbonates")])

# now we change from g to kJ/g

x <- nutrition[1,]
y <- c(37, 17, 17)
x*y
clo(x*y)

# standard correlation changes when forming subcompositions (slide 12)

cor(compo)
det(cor(compo)) # singular
cor(clo(compo[,-8]))
cor(clo(compo[,-6]))
cor(clo(compo[,-c(7:8)]))
cor(clo(compo[,-c(1,2)]))
cor(clo(compo[,1:4]))


# ilr (slide 25)

par(mfrow=c(1,2))
plot(nutrition, col=2:6)
nutritionIlr <- ilr(nutrition)
plot(nutritionIlr, col=2:6)

# straigh lines (slide 32)

a <- c(10, 50, 100)
b <- c(0.9, 0.8, 0.7) # slightly altered from slide to make effect more visible

a*b

# convert these to acomp

a <- acomp(a)
b <- acomp(b)

# "+" and "*" are now in Aitchison geometry!

a + 2*b

x <- seq(0, 100, 0.1) 

par(mfrow=c(1,2))

linepoints <- lapply(x, function(z) a + z*b  )
linepoints <- acomp(do.call(rbind, linepoints))
plot(linepoints, pch=20, cex=0.05)

plot(ilr(linepoints), type="l")

# normal distribution on the simplex (slide 36)

x <- rmvnorm(20, mean=rep(0,2), sigma=matrix(c(1,0,0,1), , nrow=2, byrow=T))
plot(x)
plot(ilrInv(x))

