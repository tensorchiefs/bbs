import argparse
import logging
import sys
import numpy as np
import argparse
import logging
import sys
import pickle
import gym
from collections import defaultdict
from gym import wrappers
from gym.core import Space
from gym.spaces import discrete
import gym
from gym import wrappers
from gym_maze.envs import MazeEnv

class RandomAgent(object):
    """The world's simplest agent!"""
    def __init__(self, action_space):
        self.action_space = action_space

    def act(self, observation, reward, done):
        return self.action_space.sample()

class QAgent(object):

    def __init__(self, observation_space_size, action_space_size):
        self.Q = np.zeros([observation_space_size, action_space_size])
        self.rewardList = []
        self.score = 0
        # Set learning parameters
        self.lr = .8
        self.y = .95
        self.eps = 0.99
        self.mapping_observation_dict = {}
        self.mapping_action_dict = {}
        self._init_mapping_dict()
        self.__init_mapping_action_dict()

    def _init_mapping_dict(self):
        self.mapping_observation_dict["0,0"] = 0
        self.mapping_observation_dict["0,1"] = 1
        self.mapping_observation_dict["0,2"] = 2
        self.mapping_observation_dict["1,0"] = 3
        self.mapping_observation_dict["1,1"] = 4
        self.mapping_observation_dict["1,2"] = 5
        self.mapping_observation_dict["2,0"] = 6
        self.mapping_observation_dict["2,1"] = 7
        self.mapping_observation_dict["2,2"] = 8
        self.mapping_observation_dict["3,0"] = 9
        self.mapping_observation_dict["3,1"] = 10
        self.mapping_observation_dict["3,2"] = 11


    def __init_mapping_action_dict(self):
        # ['N', 'E', 'S', 'W']
        self.mapping_action_dict[0] = 'N'
        self.mapping_action_dict[1] = 'E'
        self.mapping_action_dict[2] = 'S'
        self.mapping_action_dict[3] = 'W'

    def map_box_state(self, state):
        # print(state)
        key = str(int(state[0]))+ ","+ str(int(state[1]))
        return self.mapping_observation_dict[key]

    def map_action(self, action):
        return self.mapping_action_dict[action]

    def act(self, s, mode="train"):
        # epsilon greedy.
        if "train" in mode:
            action = np.argmax(self.Q[s,:]) if np.random.random() > self.eps else self.action_space.sample()
            self.eps = self.eps*0.99
        else:
            action = np.argmax(self.Q[s, :])
        return action

    def learn(self, num_episodes, env):
        self.action_space =  env.action_space
        for i in range(num_episodes):
            # Reset environment and get first new observation
            if i % 100 == 0:
                print("episode: ", i)
                print("score: ", sum(self.rewardList) / float(num_episodes))
            if i == 0:
                s = env.reset()
                s_old = s
                s = self.map_box_state(s)
                #print("mapped state: {} --> {}".format(s, s_old))
                print(s)

            rAll = 0
            d = False
            j = 0
            while True:


                # The Q-Table learning algorithm


                #print("episode: {} j = {}".format(i,j))
                # Choose an action by greedily (with noise) picking from Q table
                #a = np.argmax(self.Q[s, :] + np.random.randn(1, env.action_space.n) * (1. / (i + 1)))
                # Get new state and reward from environment
                a = self.act(s)
                a_env = self.map_action(a)
                #print("map action: {} --> {}".format(a_env, a))
                s1, r, d, _ = env.step(a_env)
                #print("s1: {}".format(s1))
                s1 = self.map_box_state(s1)

                # Update Q-Table with new knowledge
                self.Q[s, a] = self.Q[s, a] + self.lr * (r + self.y * np.max(self.Q[s1, :]) - self.Q[s, a])
                rAll += r
                s = s1
                #print("i", i)
                #print("d = ", d)
                if d == True:
                    s = env.reset()
                    s_old = s
                    s = self.map_box_state(s)
                    #print("mapped state: {} --> {}".format(s, s_old))
                    break
                # jList.append(j)
            self.rewardList.append(rAll)
        self.score = sum(self.rewardList)/float(num_episodes)
        # print(self.Q.shape)
        # print(self.Q)
        # print("****"*20)
        # for i in range(0,12):
        #     print("**** state: ", i)
        #     print(self.Q[i,:])
        print("score: ", self.score)

    def test(self, env, num_episodes=1):
        self.action_space = env.action_space
        self.rewardList = []
        for i in range(num_episodes):
            # Reset environment and get first new observation
            print("episode: ", i)
            if i == 0:
                s = env.reset()
                s_old = s
                s = self.map_box_state(s)
                print("mapped state: {} --> {}".format(s, s_old))

            rAll = 0
            d = False
            j = 0
            while True:

                # The Q-Table learning algorithm


                # print("episode: {} j = {}".format(i,j))
                # Choose an action by greedily (with noise) picking from Q table
                # a = np.argmax(self.Q[s, :] + np.random.randn(1, env.action_space.n) * (1. / (i + 1)))
                # Get new state and reward from environment
                a = self.act(s, mode="test")
                a_env = self.map_action(a)
                print("state: ", s)
                print("map action: {} --> {}".format(a_env, a))
                s1, r, d, _ = env.step(a_env)
                env.render(mode="rgb_array")
                # print("s1: {}".format(s1))
                s1 = self.map_box_state(s1)

                # Update Q-Table with new knowledge
                #self.Q[s, a] = self.Q[s, a] + self.lr * (r + self.y * np.max(self.Q[s1, :]) - self.Q[s, a])
                rAll += r
                s = s1
                # print("i", i)
                # print("d = ", d)
                if d == True:
                    s = env.reset()
                    s_old = s
                    s = self.map_box_state(s)
                    # print("mapped state: {} --> {}".format(s, s_old))
                    break
                    # jList.append(j)

            self.rewardList.append(rAll)
        self.score = sum(self.rewardList) / float(num_episodes)
        print("score: ", self.score)
        print(self.Q)

class TabularQAgent(object):

    def __init__(self, env, observation_space_size, action_space_size):
        self.env = env
        self.action_space = env.action_space

        self.Q = np.zeros([observation_space_size, action_space_size])
        self.rewardList = []
        self.score = 0
        # Set learning parameters
        self.lr = .8
        self.y = .95
        self.eps = 0.99


        self.mapping_observation_dict = {}
        self.mapping_action_dict = {}

        self._init_mapping_dict()
        self.__init_mapping_action_dict()

    def _init_mapping_dict(self):
        self.mapping_observation_dict["0,0"] = 0
        self.mapping_observation_dict["0,1"] = 1
        self.mapping_observation_dict["0,2"] = 2
        self.mapping_observation_dict["1,0"] = 3
        self.mapping_observation_dict["1,1"] = 4
        self.mapping_observation_dict["1,2"] = 5
        self.mapping_observation_dict["2,0"] = 6
        self.mapping_observation_dict["2,1"] = 7
        self.mapping_observation_dict["2,2"] = 8
        self.mapping_observation_dict["3,0"] = 9
        self.mapping_observation_dict["3,1"] = 10
        self.mapping_observation_dict["3,2"] = 11


    def __init_mapping_action_dict(self):
        # ['N', 'E', 'S', 'W']
        self.mapping_action_dict[0] = 'N'
        self.mapping_action_dict[1] = 'E'
        self.mapping_action_dict[2] = 'S'
        self.mapping_action_dict[3] = 'W'

    def map_box_state(self, state):
        # print(state)
        key = str(int(state[0]))+ ","+ str(int(state[1]))
        return self.mapping_observation_dict[key]

    def map_state_box(self, state):
        for k, v in self.mapping_observation_dict.items():
            if v == state:
                return k

    def map_action(self, action):
        return self.mapping_action_dict[action]

    def act(self, s, mode="train"):
        # epsilon greedy.
        if "train" in mode:
            action = np.argmax(self.Q[s,:]) if np.random.random() > self.eps else self.action_space.sample()
            self.eps = self.eps*0.99
        else:
            action = np.argmax(self.Q[s, :])
        return action

    def learn(self, num_episodes):
        score_per_100_episode = []
        self.rewardList = []
        for episode_i in range(num_episodes):
            # Reset environment and get first new observation
            if episode_i == 0:
                current_state = self.env.reset()
                current_state = self.map_box_state(current_state)
            if episode_i % 100 == 0:
                current_score = sum(self.rewardList) / float(num_episodes)
                #print("episode: {}  score: {}".format(episode_i, current_score))
                score_per_100_episode.append(current_score)

            episode_reward = 0
            while True:
                # The Q-Table learning algorithm
                # Choose an action by greedily (with noise) picking from Q table
                action = self.act(current_state)
                action_prepared = self.map_action(action)
                next_state, reward, done, _ = self.env.step(action_prepared)
                next_state = self.map_box_state(next_state)

                # Update Q-Table with new knowledge
                self.Q[current_state, action] = self.Q[current_state, action] + self.lr * (reward + self.y * np.max(self.Q[next_state, :]) - self.Q[current_state, action])
                episode_reward += reward
                current_state = next_state

                if done == True:
                    current_state = self.env.reset()
                    current_state = self.map_box_state(current_state)
                    break
            self.rewardList.append(episode_reward)
        self.score = sum(self.rewardList)/float(num_episodes)
        print("Mean training score: {}".format(self.score))

        # save q-table
        with open("/tmp/q_table.pickle", "wb") as file:
            pickle.dump(self.Q , file)

        return score_per_100_episode


    def evaluate(self, num_episodes=1):
        # load q_table
        with open("/tmp/q_table.pickle", "rb") as file:
            self.Q = pickle.load( file)

        self.rewardList = []
        for episode_i in range(num_episodes):
            # Reset environment and get first new observation
            print("episode: ", episode_i)
            if episode_i == 0:
                current_state = self.env.reset()
                current_state = self.map_box_state(current_state)

            episode_reward = 0
            done = False
            while True:
                # Choose an action from leared policy
                action = self.act(current_state, mode="test")
                action_prepared = self.map_action(action)
                #print("In state ({}) take action {}".format(self.map_state_box(current_state), action_prepared))

                next_state, reward, done, _ = self.env.step(action_prepared)
                next_state = self.map_box_state(next_state)

                episode_reward += reward
                current_state = next_state

                if done == True:
                    current_state = self.env.reset()
                    current_state = self.map_box_state(current_state)
                    break

            self.rewardList.append(episode_reward)
        self.score = sum(self.rewardList) / float(num_episodes)
        print("Mean testing score: ", self.score)
        print("Q Table: ")
        print(self.Q)



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument('env_id', nargs='?', default='CartPole-v0', help='Select the environment to run')
    args = parser.parse_args()
    args.env_id = 'maze-sample-3x4-v1'

    # Call `undo_logger_setup` if you want to undo Gym's logger setup
    # and configure things manually. (The default should be fine most
    # of the time.)
    gym.undo_logger_setup()
    logger = logging.getLogger()
    formatter = logging.Formatter('[%(asctime)s] %(message)s')
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # You can set the level to logging.DEBUG or logging.WARN if you
    # want to change the amount of output.
    logger.setLevel(logging.INFO)

    #env = gym.make(args.env_id)
    env = gym.make("maze-sample-3x4-v1")
    # You provide the directory to write to (can be an existing
    # directory, including one with existing data -- all monitor files
    # will be namespaced). You can also dump to a tempdir if you'd
    # like: tempfile.mkdtemp().
    #outdir = '/tmp/random-agent-results'
    outdir = '/Users/gabrieleyyi/Documents/0_Local/1_Work/0_ZHAW/1_Git_Repos/gym-maze/gym_maze/tmp/q-table'

    env = wrappers.Monitor(env, directory=outdir, force=True)
    env.seed(0)
    print("env.observation_space: {}".format(env.observation_space))
    #agent = RandomAgent(env.action_space)
    #agent = TabularQAgent(observation_space=env.observation_space, action_space=env.action_space)

    #agent = QAgent(action_space_size=env.env.action_space.n, observation_space_size=12)
    agent = TabularQAgent(env,action_space_size=env.env.action_space.n, observation_space_size=12)
    episode_count = 50
    reward = 0
    done = False

    agent.learn(1000)
    print("testing")
    agent.evaluate()
    #agent.learn(env)
    #
    # for i in range(episode_count):
    #     ob = env.reset()
    #     while True:
    #         action = agent.act(ob, reward, done)
    #         #action = agent.action_space(ob)
    #         ob, reward, done, _ = env.step(action)
    #         print("obs {0} reward {1}".format(ob, reward))
    #         if done:
    #             break
            # Note there's no env.render() here. But the environment still can open window and
            # render if asked by env.monitor: it calls env.render('rgb_array') to record video.
            # Video is not recorded every episode, see capped_cubic_video_schedule for details.

    # Close the env and write monitor result info to disk
    env.close()